
import React, { useState, useEffect } from 'react';
import type { CalculationResult } from './types';

const App: React.FC = () => {
    const FALLBACK_RATE = 4.5;
    const [itemPriceCNY, setItemPriceCNY] = useState<string>('');
    const [exchangeRate, setExchangeRate] = useState<number | null>(null);
    const [rateStatus, setRateStatus] = useState<'loading' | 'live' | 'fallback'>('loading');
    const [calculation, setCalculation] = useState<CalculationResult | null>(null);

    useEffect(() => {
        const fetchRate = async () => {
            try {
                const response = await fetch('https://api.exchangerate-api.com/v4/latest/CNY');
                if (!response.ok) throw new Error('API request failed');
                const data = await response.json();
                if (data?.rates?.TWD) {
                    setExchangeRate(data.rates.TWD);
                    setRateStatus('live');
                } else {
                    throw new Error('Invalid API response structure');
                }
            } catch (error) {
                console.error("Failed to fetch exchange rate:", error);
                setExchangeRate(FALLBACK_RATE);
                setRateStatus('fallback');
            }
        };

        fetchRate();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        const price = parseFloat(itemPriceCNY);
        if (!isNaN(price) && price > 0 && exchangeRate !== null) {
            const alipayFeeCNY = price > 200 ? price * 0.03 : 0;
            const billedCNY = price + alipayFeeCNY;
            const baseTWD = billedCNY * exchangeRate;
            const cardFeeTWD = baseTWD * 0.015;
            const totalTWD = baseTWD + cardFeeTWD;
            const finalTotalTWD = Math.ceil(totalTWD);

            setCalculation({
                itemPriceCNY: price,
                alipayFeeCNY,
                billedCNY,
                baseTWD,
                cardFeeTWD,
                finalTotalTWD,
            });
        } else {
            setCalculation(null);
        }
    }, [itemPriceCNY, exchangeRate]);

    const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setItemPriceCNY(e.target.value);
    };

    return (
        <div className="min-h-screen text-zinc-800 flex items-center justify-center p-4 font-sans">
            <main className="w-full max-w-md mx-auto bg-white rounded-xl shadow-lg border border-zinc-200/80 p-8 space-y-6">
                
                <header className="text-left">
                    <h1 className="text-2xl font-bold text-zinc-900">支付寶試算</h1>
                    <p className="text-zinc-500 mt-1 text-sm">估算支付 (CNY → TWD) 總金額</p>
                </header>

                <div>
                    <label htmlFor="price-cny" className="block text-sm font-medium text-zinc-700 mb-2">
                        付款金額 (人民幣 CNY)
                    </label>
                    <div className="relative">
                        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg font-medium text-zinc-400">¥</span>
                        <input
                            id="price-cny"
                            type="number"
                            value={itemPriceCNY}
                            onChange={handlePriceChange}
                            placeholder="0.00"
                            className="w-full bg-zinc-50 border border-zinc-300 rounded-lg text-3xl font-mono text-center text-zinc-800 py-3 pl-12 pr-4 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all duration-200"
                            min="0"
                            step="0.01"
                        />
                    </div>
                </div>
                
                {calculation ? (
                     <div className="space-y-6 animate-fade-in pt-2">
                        <div className="border-t border-zinc-200 pt-6">
                          <p className="text-sm text-zinc-600">預估總金額 (台幣 TWD)</p>
                          <p className="text-5xl font-bold text-zinc-900 tracking-tight mt-1 flex items-baseline">
                              <span className="text-3xl font-medium pr-2">NT$</span>
                              {calculation.finalTotalTWD.toLocaleString()}
                          </p>
                        </div>
                        
                        <div className="space-y-3 text-sm">
                            <h3 className="text-base font-medium text-zinc-800 mb-2">費用明細</h3>
                            <div className="flex justify-between items-center text-zinc-600">
                                <span>當前匯率</span>
                                {rateStatus === 'loading' ? (
                                    <div className="h-5 w-20 bg-zinc-200 rounded animate-pulse"></div>
                                ) : (
                                    <div className="flex items-center gap-2">
                                        <span className="font-mono">{exchangeRate?.toFixed(4)}</span>
                                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                                            rateStatus === 'live' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                                        }`}>
                                            {rateStatus === 'live' ? '即時' : '備用'}
                                        </span>
                                    </div>
                                )}
                            </div>
                            <div className="flex justify-between items-center text-zinc-600">
                                <span>支付寶服務費</span>
                                <span className="font-mono">¥ {calculation.alipayFeeCNY.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between items-center text-zinc-600">
                                <span>海外交易手續費</span>
                                <span className="font-mono">NT$ {calculation.cardFeeTWD.toFixed(2)}</span>
                            </div>
                        </div>
                    </div>
                ) : (
                    <div className="text-center py-10 border-t border-zinc-200">
                      <p className="text-zinc-400">請輸入金額以進行計算</p>
                    </div>
                )}
            </main>
        </div>
    );
};

export default App;
