
export interface CalculationResult {
  itemPriceCNY: number;
  alipayFeeCNY: number;
  billedCNY: number;
  baseTWD: number;
  cardFeeTWD: number;
  finalTotalTWD: number;
}
